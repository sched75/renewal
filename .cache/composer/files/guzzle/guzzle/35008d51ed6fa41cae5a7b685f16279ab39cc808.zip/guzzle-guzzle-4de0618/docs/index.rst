.. title:: Guzzle | PHP HTTP client and framework for consuming RESTful web services
.. toctree::
    :hidden:

    docs.rst
